"""Scripts package root."""

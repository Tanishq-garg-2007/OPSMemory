"""Core foundational utilities."""

"""Memory module package root."""
